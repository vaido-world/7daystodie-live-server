#!/bin/bash
apt update
apt install p7zip-full -y
apt install p7zip-rar -y 
7z a "./Minimal_setup.zip" "../7_Days_To_Die_Dedicated_Server/"