<nav>
		<pre id="test" style="background: white; border: black solid 1px; width: fit-content; tab-size: 0; padding-right: 12px; padding-left: 9px;"><strong>Currently running 7dtd Screen Session on the server</strong>
			<?php echo shell_exec("cat \"$(ls -rt /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data/*.txt | tail -n1)\""); ?>
			</pre>
</nav>


 <script>

 setTimeout(function(){
 window.scrollTo(0,document.body.scrollHeight);

}, 100);
 
 

 </script>