echo test
# ls -rt /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data/*.txt
# cat "${ls -rt /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data/*.txt | tail -n1}"

cat "$(ls -rt /home/steam/.local/share/Steam/steamcmd/7dtd/7DaysToDieServer_Data/*.txt | tail -n1)"