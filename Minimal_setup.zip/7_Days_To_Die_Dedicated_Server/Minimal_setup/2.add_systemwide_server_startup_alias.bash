#!/bin/bash

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
# echo "Script directory: $SCRIPT_DIR"

echo "alias foo='echo yes'" > /etc/profile.d/7dtd-server-aliases.sh
echo "alias back='cd $SCRIPT_DIR'" >> /etc/profile.d/7dtd-server-aliases.sh
echo "alias 7dtd='cd /home/steam/.local/share/Steam/steamcmd/7dtd'" >> /etc/profile.d/7dtd-server-aliases.sh
#echo "alias 7dtd_start='bash /home/steam/.local/share/Steam/steamcmd/7dtd/startserver_with_security.sh'" >> /etc/profile.d/7dtd-server-aliases.sh

# Restart is for restarting and starting.
echo "alias 7dtd_restart='bash $SCRIPT_DIR/announce_server_update/server_restart.bash'" >> /etc/profile.d/7dtd-server-aliases.sh


# Replace/restart bash itself
# Note that this won't affect things such as the cwd or exported variables.
exec bash -l