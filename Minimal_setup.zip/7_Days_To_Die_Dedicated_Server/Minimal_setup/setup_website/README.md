## Original Icon
https://opengameart.org/content/nuclear-power-plant-symbols-svg

## Convert .svg to .webp
https://www.online-convert.com/result/f7e44e9e-bf70-4b0c-a734-21eea2b43c17

## CSS layout
https://lawleyfall2018.github.io/230-fall2018/weekly_materials/week6/gridExercise.html
